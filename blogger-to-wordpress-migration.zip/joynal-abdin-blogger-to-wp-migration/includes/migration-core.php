<?php
function jab_fetch_blogger_posts_paginated($api_key, $blog_id, $start_index = 1) {
    $url = "https://www.googleapis.com/blogger/v3/blogs/" . $blog_id . "/posts?key=" . $api_key . "&maxResults=10&startIndex=" . $start_index;
    $response = wp_remote_get($url);

    if (is_wp_error($response)) {
        return array();
    }

    $body = wp_remote_retrieve_body($response);
    return json_decode($body, true);
}

function jab_ajax_import_handler() {
    $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
    $blog_id = isset($_POST['blog_id']) ? sanitize_text_field($_POST['blog_id']) : '';
    $start_index = isset($_POST['start_index']) ? intval($_POST['start_index']) : 1;

    $data = jab_fetch_blogger_posts_paginated($api_key, $blog_id, $start_index);
    if (empty($data) || !isset($data['items'])) {
        wp_send_json_error(array('message' => 'No posts found.'));
    }

    $titles = array();
    foreach ($data['items'] as $post) {
        if (!isset($post['title'], $post['content'])) continue;

        $post_id = wp_insert_post(array(
            'post_title'   => $post['title'],
            'post_content' => $post['content'],
            'post_status'  => 'publish',
            'post_date'    => isset($post['published']) ? $post['published'] : current_time('mysql'),
            'post_type'    => 'post'
        ));

        if ($post_id) {
            $titles[] = $post['title'];
        }
    }

    $total = isset($data['totalItems']) ? intval($data['totalItems']) : $start_index + count($titles);
    wp_send_json_success(array(
        'titles' => $titles,
        'done'   => $start_index + count($titles) - 1,
        'total'  => $total
    ));
}
add_action('wp_ajax_jab_ajax_import', 'jab_ajax_import_handler');

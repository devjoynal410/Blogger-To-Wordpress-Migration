<?php
/**
 * Plugin Name: Blogger to WordPress Migration
 * Plugin URI: https://devjoynal.com
 * Description: Migrate your entire Blogger blog to WordPress professionally with full content, images, metadata, and SEO-friendly redirection. This plugin supports bulk import with real-time progress UI, automatic featured image assignment, clean content optimization, and powerful duplicate protection. Enhance your workflow with built-in search-replace functionality and automated email notifications upon completion.
 * Version: 3.1
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Joynal Abdin
 * Author URI: https://devjoynal.com
 * License: GPL2
 */

defined('ABSPATH') or die('No direct access allowed.');

require_once plugin_dir_path(__FILE__) . 'includes/migration-core.php';
require_once plugin_dir_path(__FILE__) . 'admin/admin-panel.php';

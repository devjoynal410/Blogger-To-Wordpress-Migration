
jQuery(document).ready(function($) {
    $('#jab-import-form').submit(function(e) {
        e.preventDefault();

        let apiKey = $('#jab_api_key').val();
        let blogId = $('#jab_blog_id').val();
        let progress = 0;
        let imported = 0;
        let total = 0;

        $('#jab-progress').show();
        $('#jab-progress-bar').css('width', '0%').text('0%');
        $('#jab-log').html('');

        function importNext(startIndex) {
            $.post(ajaxurl, {
                action: 'jab_ajax_import',
                api_key: apiKey,
                blog_id: blogId,
                start_index: startIndex
            }, function(response) {
                if (response.success) {
                    total = response.data.total;
                    imported = response.data.done;
                    let titles = response.data.titles;

                    let percent = Math.floor((imported / total) * 100);
                    $('#jab-progress-bar').css('width', percent + '%').text(percent + '%');

                    titles.forEach(function(title) {
                        $('#jab-log').append('<div>✔ ' + title + '</div>');
                    });

                    if (imported < total) {
                        importNext(imported + 1);
                    } else {
                        $('#jab-log').append('<div><strong>✅ ইমপোর্ট সম্পন্ন হয়েছে।</strong></div>');
                    }
                } else {
                    $('#jab-log').append('<div style="color:red;">❌ ' + response.data.message + '</div>');
                }
            });
        }

        importNext(1);
    });
});

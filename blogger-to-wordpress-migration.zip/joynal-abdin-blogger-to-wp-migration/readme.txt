=== Blogger to WordPress Migration ===
Contributors: devjoynal
Donate link: https://devjoynal.com
Tags: blogger, migration, wordpress importer, blogger to wp, blogger to wordpress
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 3.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A complete Blogger to WordPress migration plugin with support for posts, images, comments, SEO redirection, live progress log, and advanced content cleaning.

== Description ==

Joynal Abdin – Blogger to WordPress Migration helps you transfer your entire Blogger site to WordPress in a few clicks. It supports:
- Full post import via Blogger API v3
- Image migration to WordPress media
- Auto-featured image assignment
- Clean content (removes <script>, ads, and attribution)
- Duplicate post prevention and overwrite option
- Search and Replace in post content (e.g., image path to CDN)
- Live AJAX-based import UI with progress bar
- Automatic email notification after import completion

Perfect for large blogs with thousands of posts.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu
3. Navigate to Dashboard → Blogger Migration
4. Enter your Blogger API Key and Blog ID
5. Click "Start Import"

== Screenshots ==

1. Import UI with progress bar and live title log
2. Settings form for API key and blog ID
3. Featured image auto-detection in action

== Changelog ==

= 3.1 =
* Added featured image auto-detect
* Added progress bar and real-time import log
* Added email notification on import completion
* Added duplicate protection and clean content system
* Fixed admin menu visibility
* Added WordPress.org compatible structure

== Frequently Asked Questions ==

= Does this support SEO redirection? =
Yes, Blogger URLs are saved as meta and redirected via 301 if user lands on old links.

= Will it import images? =
Yes, all images are downloaded and re-linked in WordPress media library.

= Can I import again without duplicates? =
Yes, already imported posts are skipped unless overwrite is enabled.

== Upgrade Notice ==

= 3.1 =
This version adds WordPress.org compatible structure, major bug fixes, and featured enhancements.

<?php
function jab_migration_admin_menu() {
    add_menu_page(
        __('Blogger to WP Migration', 'jab-blogger'),
        __('Blogger Migration', 'jab-blogger'),
        'manage_options',
        'jab-blogger-migration',
        'jab_migration_settings_page',
        'dashicons-migrate',
        20
    );
}
add_action('admin_menu', 'jab_migration_admin_menu');

function jab_migration_settings_page() {
    echo '<div class="wrap">
        <h1>Blogger থেকে WordPress মাইগ্রেশন</h1>
        <form id="jab-import-form" method="post">
            <table class="form-table">
                <tr><th scope="row">Blogger API Key</th>
                    <td><input type="text" id="jab_api_key" class="regular-text" required></td></tr>
                <tr><th scope="row">Blogger Blog ID</th>
                    <td><input type="text" id="jab_blog_id" class="regular-text" required></td></tr>
            </table>
            <p class="submit"><button type="submit" class="button button-primary">ইমপোর্ট শুরু করুন</button></p>
        </form>
        <div id="jab-progress" style="display:none;margin-top:20px;">
            <div style="background:#e0e0e0;height:30px;width:100%;border-radius:5px;">
                <div id="jab-progress-bar" style="background:#0073aa;height:30px;width:0%;color:#fff;text-align:center;line-height:30px;border-radius:5px;">0%</div>
            </div>
            <div id="jab-log" style="margin-top:15px;font-size:14px;"></div>
        </div>
    </div>';
}

function jab_enqueue_admin_scripts($hook_suffix) {
    if ($hook_suffix === 'toplevel_page_jab-blogger-migration') {
        wp_enqueue_script('jab-import-js', plugin_dir_url(__FILE__) . '../js/import.js', array('jquery'), null, true);
    }
}
add_action('admin_enqueue_scripts', 'jab_enqueue_admin_scripts');
